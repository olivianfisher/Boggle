#include "boggle.h"

Boggle::Boggle()
{
  // TODO
}

Boggle::~Boggle()
{
  // TODO
}

string Boggle::getBoardString()
{
  // TODO
}

void Boggle::createRandomBoard()
{
  // TODO
}

bool Boggle::importBoard(string file_name)
{
  // TODO
}

bool Boggle::importDictionary(string file_name)
{
  // TODO
}

void Boggle::setMinWordLength(int length)
{
  // TODO
}

bool Boggle::isWord(string word)
{
  // TODO
}

bool Boggle::isPrefix(string prefix)
{
  // TODO
}

bool Boggle::findPrefix(string root, int start, int end, bool fullWordOnly)
{
  // TODO
}

set<string> Boggle::solveBoard()
{
  // TODO
}

void Boggle::findWords(string root, unordered_set<string> path, set<string>& wordsFound, int x, int y)
{
  // TODO
}

void Boggle::clear()
{
  // TODO
}

void Boggle::setBoard(string boardValues[SIZE][SIZE])
{
  // TODO
}
